<?php
/** @wordpress-plugin
 * Author:            GHAX
 * Author URI:        https://leadtrail.io/
 */

class leadtrail_Deactivator {
	/* De-activate Class */
	public static function deactivate_leadtrail() {
		/* Delete Table And Post type*/
		global $wpdb;	

	}
}