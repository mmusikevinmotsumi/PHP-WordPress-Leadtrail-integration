<div class="container section-top">
  <div class="row logo">
    <div class="col-md-6 logo1"><img src="<?php echo GHAX_LEADTRAIL_RELPATH; ?>includes/img/leadtrail-logo.jpeg" /></div>
    <div class="col-md-6 logo2"><img src="<?php echo GHAX_LEADTRAIL_RELPATH; ?>includes/img/help.png"><a href="https://leadtrail.io/support" target="_blank">Help</a></div>
  </div>
</div>